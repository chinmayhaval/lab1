#include<stdio.h>
#include<stdlib.h>
int x,y,z;

void p(int *x){
    printf("%p ooo",x);
    printf("%d",*x);


}

int main(){
    int a;
    int *p;
    a=p

    printf("%d",a);
    
}